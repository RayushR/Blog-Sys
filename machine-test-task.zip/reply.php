<?php
include("auth_session.php");
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['comment_id']) && isset($_POST['reply_text'])) {
    $commentId = $con->real_escape_string($_POST['comment_id']);
    $replyText = $con->real_escape_string($_POST['reply_text']);
    $insert_sql = "INSERT INTO reply (comment_id, reply_data) VALUES ('$commentId', '$replyText')";
    
    if ($con->query($insert_sql) === true) {
        echo "Reply saved successfully ✅";
    } else {
        echo "Error: " . $con->error;
    }
}


?>