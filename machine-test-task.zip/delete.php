<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Retrieve the item ID from the POST data
  $itemId = $_POST['id'];
  include("db.php");
  
  $sql = "DELETE FROM `post` WHERE `id` = $itemId";
  if ($con->query($sql) === TRUE) {
    // Deletion successful
    echo "Item deleted successfully";
  } else {
    echo "Error deleting item: " . $con->error;
  }
  $con->close();
}
?>
