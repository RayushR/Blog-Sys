 <?php
include("auth_session.php");
include("db.php");
$curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);

include 'user.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Post Portal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  <link rel="stylesheet" href="css/parsley.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0-alpha3/css/bootstrap.min.css">
  <style>
     * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #fff;
            overflow: hidden;
        }

        .navbar a {
            float: left;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        .navbar .logo {
            float: left;
            margin-right: 20px;
        }

        .navbar .logout-btn {
            float: right;
        }
        .logout-btn{
          background-color: red;
          border-radius: 4px;
        }
        table.nowrap td th{
          white-space: nowrap;
        }
        .table-container {
            overflow-x: auto;
        }
        @media screen and (max-width: 600px) {
            .navbar a {
                float: none;
                display: block;
                text-align: left;
            }

            .navbar .logo,
            .navbar .logout-btn {
                float: none;
                display: block;
                text-align: center;
            }
        }
    </style>
</head>

<body style="overflow-x: hidden;">
<div class="navbar" style="background-color: #d7d7d7;">
    <a href="" class="logo" style="color: #000; font-weight: 800;">LOGO</a>
    <a href="logout.php" class="logout-btn">Logout</a>
</div>
<br><br>
  <div class="container form">
        <div class="row">
          <h4 class="text-center"><?php if (!empty($name)) {echo "Name: " . $name;} else {echo "<script>window.location.href = 'logout.php';</script>";exit();}?></h4>
          <h5 class="text-center"><?php if (!empty($name)) {echo "Roll no: " . $roll_no; } else {echo "<script>window.location.href = 'logout.php';</script>";exit();}?></h5>
          <h6 class="text-center"><?php if (!empty($name)) {echo "Email: " . $email; } else {echo "<script>window.location.href = 'logout.php';</script>";exit();}?></h6>
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="card">
                    <h4 class="text-center mt-3">Create Post</h4>
                    <div class="card-body">
                    <form action="#" method="POST" autocomplete="off" data-parsley-validate="true" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" name="title" data-parsley-required="true" data-parsley-required-message="Please Enter Title" class="form-control" id="title">
                            <input type="hidden" name="user_id" id="user_id" value="<?php echo $id;?>">
                        </div>
                        <div class="mb-3">
                            <label for="formFile" class="form-label">Upload Image</label>
                            <input class="form-control" type="file" name="file" id="formFile" data-parsley-required="true" data-parsley-required-message="Please Select Image">
                        </div>
                        <div class="mb-3">
                            <label for="editor" class="form-label">Blog Content</label>
                            <textarea class="form-control" name="des" data-parsley-required="true" data-parsley-required-message="Please Write Your Content" rows="5"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="keywords" class="form-label">Date</label>
                            <input type="date" name="date" data-parsley-required="true"  data-parsley-required="true" class="form-control" id="date">
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                        </div>
    <?php
    // $servername = "localhost";
    // $username = "root";
    // $password = "";
    // $db = "blog";

    // // Create connection
    // $con = new mysqli($servername, $username, $password, $db);

    // if ($con->connect_error) {
    //     die("Connection failed: " . $con->connect_error);
    // }

    if (isset($_POST['submit'])) {
        // Retrieve form data
        $title = $_POST['title'];
        $des = $_POST['des'];
        $date = $_POST['date'];
        $user_id = $_POST['user_id'];
        $title = str_replace("'","\'","$title");
        $des = str_replace("'","\'","$des");
        // Handle image upload
        $image = $_FILES['file']['name'];
        $target = "upload/" . basename($image);
        $imageFileType = strtolower(pathinfo($target, PATHINFO_EXTENSION));

        // Check file type and size
        $allowedTypes = array('jpg', 'jpeg', 'png', 'webp');
        $maxFileSize = 1 * 1024 * 1024; // 1 MB

        if (in_array($imageFileType, $allowedTypes) && $_FILES['file']['size'] <= $maxFileSize) {
            move_uploaded_file($_FILES['file']['tmp_name'], $target);

            // Insert data into the database
            $sql = "INSERT INTO `post` (`title`, `user_id`, `des`, `img`, `date`) VALUES ('$title', '$user_id', '$des', '$image', '$date')";
            if ($con->query($sql) === true) {
              echo "<script>alert('Blog Save Successfully ✅ ');</script>";
                ?>
                <script type="text/javascript">
                    window.location = "<?php echo $curPageName;?>";
                </script>
                <?php
            } else {
                // echo "Error: " . $sql . "<br>" . $con->error;
                echo "Error Something Went Wrong" . $con->error;
            }
        } else {
            echo "<script>alert('Invalid file format or size. Only JPG, JPEG, PNG, and WEBP files up to 1 MB are allowed.');</script>";
            ?>
            <script type="text/javascript">
                window.location = "<?php echo $url;?>";
            </script>
            <?php
        }
    }
    ?>
</form>
                    </div>
                </div>
            </div>
            <div class="col-md-3"></div>
        </div>
        <br><br>
        <hr>
        <br>
        <div class="row mt-5">
          <div class="col-md-12">
            <div class="table-container table-responsive">
              <table id="myTable" class="table table-striped display  border border-secondary ">
                <thead>
                  <tr>
                    <th class='border border-secondary'>S no.</th>
                    <th class='border border-secondary'>Title</th>
                    <th class='border border-secondary'>Content</th>
                    <th class='border border-secondary'style="width: 80px;">Image</th>
                    <th class='border border-secondary'>Date</th>
                    <th class='border border-secondary'>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  // if ($id) {
                    $sql = "SELECT * FROM `post` ORDER BY `post`.`id` ASC";
                    $result = $con->query($sql);
                
                    $serialNumber = 1;
                
                    if ($result->num_rows > 0) {
                        // Output data for each row using a foreach loop
                        foreach ($result as $row) {
                            echo "<tr>";
                            echo "<td class='border border-secondary'>" . $serialNumber . "</td>";
                            echo "<td class='border border-secondary'>" . substr($row['title'], 0, 50) . "</td>";
                            echo "<td class='border border-secondary'>" . substr($row['des'], 0, 50) . "</td>";
                            echo "<td class='border border-secondary'><img src='upload/" . $row['img'] . "' alt='" . $row['title'] . "' style='width: 55px;'></td>";
                            echo "<td class='border border-secondary'>" . $row['date'] . "</td>";
                            echo "<td class='border border-secondary'>
                                <button type='button' class='btn btn-danger' onclick='deleteItem(" . $row['id'] . ")'>Delete</button>
                                <a href='view.php?id=" . $row['id'] . "'><button type='button' class='btn btn-primary'>View</button></a>
                                </td>";
                            echo "</tr>";
                            $serialNumber++;
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center'>No posts found for user </td></tr>";
                    }
                
                    $stmt->close();
                // } else {
                //     echo "<tr><td colspan='6' class='text-center'>Not found</td></tr>";
                // }
                
                // Close the database connection
                $con->close();
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>


            </div>
        </div>
    </div>
    
  <!-- <div class="container">
    <div class="alert alert-success my-5">
      Welcome ! You are now signed in to your account.
    </div>
    <div class="row justify-content-center">
      <div class="col-lg-5 text-center">
        <img src="./img/blank-avatar.jpg" class="img-fluid rounded" alt="User avatar" width="180">
        <h4 class="my-4">Hello, <?= htmlspecialchars($_SESSION["username"]); ?></h4>
        <a href="./logout.php" class="btn btn-primary">Log Out</a>
      </div>
    </div>
  </div> -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // delete
        function deleteItem(itemId) {
            if (confirm("Are you sure you want to delete this item?")) {
            $.ajax({
                url: 'delete.php',
                method: 'POST',
                data: { id: itemId },
                success: function(response) {
                console.log(response);
                location.reload();
                },
                error: function(xhr, status, error) {
                console.log(error);
                }
            });
            }
        }
    </script>
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="js/parsley.js"></script>


  <!-- <script src="js/jquery.min.js"></script> -->
</body>

</html>