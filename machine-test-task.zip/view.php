<?php
   include("auth_session.php");
       include("db.php");
       if (isset($_GET['id'])) {
         $post_id = $con->real_escape_string($_GET['id']);
     
         $sql = "SELECT * FROM `post` WHERE `post`.`id` = '$post_id'";
         $result = $con->query($sql);
     
         if ($result && $result->num_rows > 0) {
             $rowdata = $result->fetch_assoc();
         } else {
             header("Location: dashboard.php");
             exit();
         }
     }
       // $sql = "SELECT * FROM `post` WHERE `post`.`id` = '".$_GET['id']."' ;";
       // $rowdata = $con->query($sql)->fetch_assoc();
       $curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
       include 'user.php';
       ?>
<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Blog Detail </title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
   </head>
   <body>
      <div class="container">
         <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
               <img class="w-100 my-3" src="upload/<?php echo $rowdata['img'];?>" />
            </div>
            <div class="col-md-2"></div>
         </div>
         <div style="max-width: 700px; top: -80px;" class="mx-auto text-secondary">
            <h3 class="font-weight-bold text-dark"><?php echo $rowdata['title'];?></h3>
            <small><?php $date = strtotime($rowdata['date']); echo date('d M Y', $date);?></small>
            <p class="my-2" style="line-height: 2;"><?php echo $rowdata['des'];?></p>
            <br>    
            <?php
               if ($_GET['id']) {
                 $sql = "SELECT * FROM comment WHERE blog_id = ".$_GET['id']." ORDER BY id ASC";
                 $result = $con->query($sql);
               
                 if ($result && $result->num_rows > 0) {
                   foreach ($result as $row) {
                       echo "<blockquote class='text-primary p-3 font-italic' style='border-left: 4px solid black; line-height: 2;'>" . $row['comment_data'] . "<br>
                           <small style='color: #000;'><i>" . $name . "</i></small><br>
                           <small style='color: #000;'>" . date_format(date_create($row['date']), 'd M Y') . "</small><br>
                           ";
                           ?>
            <h6>All Reply</h6>
            <?php $comment_id = $con->real_escape_string($row['id']);
               $sql = "SELECT * FROM reply WHERE comment_id = $comment_id ORDER BY id ASC";
               $result_reply = $con->query($sql);
               
               if ($result_reply && $result_reply->num_rows > 0) {
                   foreach ($result_reply as $comment_row) {
                       echo "<p>" . $comment_row['reply_data'] . "</p>";
                   }
               }?>
            <form id="replyForm" method='post'>
               <input type='hidden' name='comment_id' value='<?php echo $row['id'];?>'>
               <textarea class='form-control' id='reply' name='reply_text' rows='1'></textarea>
               <button type='button' id='submitReply' class="btn btn-outline-dark mt-2">Reply</button>
            </form>
            </blockquote>
            <?php
               }
               } else {
               echo "<p>No comments found for blog post</p>";
               }
               } else {
               echo "<p>Invalid or missing 'id' parameter in the URL</p>";
               }
               
               ?>
            <br>
            <br>
            <form method="post" action="#">
               <div class="mb-3">
                  <label for="comment" class="form-label">Comment</label>
                  <input type="hidden" name="blog_id" value="<?php echo $rowdata['id'];?>">
                  <textarea class="form-control" id="comment" name="comment" rows="3"></textarea>
               </div>
               <div class="d-grid gap-2 mb-3">
                  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
               </div>
               <?php
                  if (isset($_POST['submit'])) {
                    $blog_id = $con->real_escape_string($_POST['blog_id']);
                    $comment = $con->real_escape_string($_POST['comment']);
                    $insert_sql = "INSERT INTO comment (blog_id, comment_data) VALUES ('$blog_id', '$comment')";
                    
                    if ($con->query($insert_sql) === true) {
                        echo "<script>alert('Comment saved successfully ✅ ');</script>";
                        ?>
               <script type="text/javascript">
                  window.location = "<?php echo $curPageName . '?id=' . $_GET['id'];?>";
               </script>
               <?php
                  } else {
                      echo "Error: " . $con->error;
                  }
                  }
                  ?>
            </form>
         </div>
      </div>
      <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
      <script>
         $(document).ready(function() {
             $('#submitReply').on('click', function() {
                 var commentId = $('[name="comment_id"]').val();
                 var replyText = $('[name="reply_text"]').val();
         
                 // Make Ajax request
                 $.ajax({
                     type: 'POST',
                     url: 'reply.php',
                     data: {
                         comment_id: commentId,
                         reply_text: replyText
                     },
                     success: function(response) {
                         alert('Reply saved successfully ✅');
                         location.reload();
                     },
                     error: function(error) {
                         console.error('Error:', error);
                     }
                 });
             });
         });
      </script>
      </script>
   </body>
</html>