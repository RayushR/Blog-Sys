<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <title>Registration</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/parsley.css"/>
</head>
<body>
<?php
    require('db.php');
    // When form submitted, insert values into the database.
    if (isset($_REQUEST['username'])) {
        // removes backslashes
        $username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
        $username = mysqli_real_escape_string($con, $username);
        $email    = stripslashes($_REQUEST['email']);
        $email    = mysqli_real_escape_string($con, $email);
        $roll    = stripslashes($_REQUEST['roll']);
        $roll    = mysqli_real_escape_string($con, $roll);
        $password = stripslashes($_REQUEST['confirmPassword']);
        $password = mysqli_real_escape_string($con, $password);
        $create_datetime = date("Y-m-d H:i:s");
        $query    = "INSERT into `users` (username, password, email, roll, create_datetime)
                     VALUES ('$username', '" . md5($password) . "', '$email', '$roll', '$create_datetime')";
        $result   = mysqli_query($con, $query);
        if ($result) {
            echo "<script>alert('Student Created Successfully! ✅');
            window.location.href = 'login.php';
            </script>";
        } else {
            echo "<div class='form'>
                  <h3>Required fields are missing.</h3><br/>
                  <p class='link'>Click here to <a href='registration.php'>registration</a> again.</p>
                  </div>";
        }
    } else {
?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-2">
            </div>
            <div class="col-md-8">
                <div class="card">
                <div class="card-body">
                    <form class="" action="" method="post" data-parsley-validate="true" novalidate="">
                        <h1 class="text-center">Registration</h1>
                        <div class="mt-4">
                            <label class="col-form-label">Name <abbr title="Required" class="text-danger">*</abbr> </label>
                            <input type="text" class="form-control" data-parsley-error-message="Enter Your Name" name="username" placeholder="Username" data-parsley-required="true" />
                        </div>
                            <div>
                            <label class="col-form-label">Email <abbr title="Required" class="text-danger">*</abbr> </label>
                            <input type="text" class="form-control" name="email" data-parsley-error-message="Enter Your Email" placeholder="Email Adress" data-parsley-required="true">
                        </div>
                            <div>
                            <label class="col-form-label">Roll No. <abbr title="Required" class="text-danger">*</abbr> </label>
                            <input type="text" class="form-control" data-parsley-error-message="Enter Your Roll" name="roll" placeholder="Roll No." data-parsley-required="true">
                        </div>
                            <div>
                            <label class="col-form-label">Password <abbr title="Required" class="text-danger">*</abbr> </label>
                            <input type="password" class="form-control" id="password" name="password" value="" required="" data-parsley-minlength="8" data-parsley-maxlength="12" data-parsley-pattern="/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,20}$/" data-parsley-trigger="change" data-parsley-id="13" data-parsley-required="true">
                        </div>
                            <div  class="mb-3">
                            <label class="col-form-label">Comfirm Password <abbr title="Required" class="text-danger">*</abbr> </label>
                            <input type="password" class="form-control" id="confirmPasswordInput" name="confirmPassword" value="" data-parsley-equalto="#password" data-parsley-error-message="Password & confirm password should be the same" required data-parsley-trigger="change" data-parsley-required="true"/> 
                            <small>Password should be Minimum 8 to 12 characters with different classes of characters in password. Classes of characters is: Lower Case, Upper Case, Digits, Special Characters.</small>   
                        </div>
                        <div class="d-grid gap-2 ">
                            <input type="submit" name="submit" value="Register" class="btn btn-primary">
                        </div>
                            <p class="link">Already have an account? <a href="login.php">Login here</a></p>
                    </form>
                </div>
                </div>
            </div>
            <div class="col-md-2">
            </div>
        </div>
    </div>
<?php
    }
?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/parsley.js"></script>
</body>
</html>
