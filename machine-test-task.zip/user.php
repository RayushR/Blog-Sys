<?php
$user_session_username = $_SESSION['username'];
// Prepare and execute a SQL query
$sql = "SELECT * FROM users WHERE roll = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("s", $user_session_username);
$stmt->execute();
$result = $stmt->get_result();

// Check if there are any rows
if ($result->num_rows > 0) {
    // Fetch data for the user
    $user_data = $result->fetch_assoc();
    $id = $user_data['id'];
    $name = $user_data['username'];
    $email = $user_data['email'];
    $roll_no = $user_data['roll'];
} else {
    echo "User not found";
}
?>