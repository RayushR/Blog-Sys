<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/parsley.css"/>
    <!-- <link rel="stylesheet" href="style.css"/> -->
</head>
<body>
<?php
    require('db.php');
    session_start();
    if (isset($_POST['username'])) {
        $username = stripslashes($_REQUEST['username']); 
        $username = mysqli_real_escape_string($con, $username);
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($con, $password);
        $query    = "SELECT * FROM `users` WHERE roll='$username'
                     AND password='" . md5($password) . "'";
        $result = mysqli_query($con, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        if ($rows == 1) {
            $_SESSION['username'] = $username;
            // Redirect to user dashboard page
            header("Location: dashboard.php");
        } else {
            echo "<script>alert('Wrong!');
            window.location.href = 'login.php';
            </script>";
        }
    } else {
?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <form class="form" method="post" data-parsley-validate="true" name="login">
                            <h1 class="login-title">Login</h1>
                            <div>
                                <label class="col-form-label">Roll No. <abbr title="Required" class="text-danger">*</abbr> </label>
                                <input type="text" class="form-control" data-parsley-required="true" data-parsley-error-message="Enter Your Roll" name="username" placeholder="Roll No.">
                            </div>
                            <div class="mb-3">
                                <label class="col-form-label">Password <abbr title="Required" class="text-danger">*</abbr> </label>
                                <input type="password" class="form-control" data-parsley-required="true" id="password" name="password" value="" placeholder="Password" >
                            </div>
                            <div class="d-grid gap-2">
                                <input type="submit" value="Login" name="submit" class="btn btn-primary"/>
                            </div>
                            <p class="link">Don't have an account? <a href="registration.php">Registration Now</a></p>
                        </form>
                        </div>
                </div>
            </div>
        </div>
    </div>
<?php
    }
?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/parsley.js"></script>
</body>
</html>
